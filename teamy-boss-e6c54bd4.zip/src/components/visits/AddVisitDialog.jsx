
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadFile } from "@/api/integrations";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Upload, Star } from "lucide-react";
import { format } from "date-fns";

const initialFormData = {
  location: "",
  visit_date: new Date(),
  visit_time: "",
  kitchen_food_tried: "",
  kitchen_wait_time: "",
  kitchen_food_review: "",
  bar_dessert_tried: "",
  bar_wait_time: "",
  bar_food_review: "",
  bar_cleanliness_score: 8,
  kitchen_cleanliness_score: 8,
  floor_cleanliness_score: 8,
  tasks_completed: [],
  overall_notes: "",
  photos: [],
  additional_photos: []
};

export default function AddVisitDialog({ open, onOpenChange, onSubmit, visitToEdit }) {
  const [formData, setFormData] = useState(initialFormData);
  const [isUploading, setIsUploading] = useState(false);
  const isEditing = !!visitToEdit;

  useEffect(() => {
    if (open) {
      if (visitToEdit) {
        // This logic is now more robust to prevent crashes from null/undefined data
        setFormData({
          ...initialFormData, // Base defaults to ensure all fields exist
          ...visitToEdit,     // Override with data from the visit being edited
          visit_date: new Date(visitToEdit.visit_date), // Ensure it's a Date object
          // Use nullish coalescing to set default scores if they are missing
          bar_cleanliness_score: visitToEdit.bar_cleanliness_score ?? 8,
          kitchen_cleanliness_score: visitToEdit.kitchen_cleanliness_score ?? 8,
          floor_cleanliness_score: visitToEdit.floor_cleanliness_score ?? 8,
          // IMPORTANT FIX: Ensure arrays are initialized even if they are null/undefined in the source data
          tasks_completed: visitToEdit.tasks_completed || [],
          photos: visitToEdit.photos || [],
          additional_photos: visitToEdit.additional_photos || [],
        });
      } else {
        setFormData(initialFormData); // Reset to initial state for new visit
      }
    }
  }, [visitToEdit, open]); // Depend on visitToEdit and open to re-initialize form

  const taskOptions = [
    "到 Eats365 查看營業額",
    "到 Inline 留意訂位情況",
    "到 TEAMY 了解排更情況",
    "與當日店長 / 副店長溝通 10 分鐘",
    "與大廚溝通 5 - 10 分鐘"
  ];

  const waitTimeOptions = [
    "Less Than 5 Min",
    "5-10 min",
    "10-15 min",
    "15-20 min",
    "20-25 min",
    "25 min +"
  ];

  const handleFileUpload = async (files, fieldName) => {
    setIsUploading(true);
    try {
      const uploadPromises = Array.from(files).map(file => UploadFile({ file }));
      const uploads = await Promise.all(uploadPromises);
      const urls = uploads.map(upload => upload.file_url);
      
      setFormData(prev => ({
        ...prev,
        [fieldName]: [...(prev[fieldName] || []), ...urls]
      }));
    } catch (error) {
      console.error("Error uploading files:", error);
      alert("Failed to upload some files. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleTaskToggle = (task, checked) => {
    setFormData(prev => ({
      ...prev,
      tasks_completed: checked
        ? [...prev.tasks_completed, task]
        : prev.tasks_completed.filter(t => t !== task)
    }));
  };

  const handleSubmit = () => {
    // Simplified validation - removed character count requirements
    if (!formData.location) {
      alert("Please select a location.");
      return;
    }
    if (!formData.overall_notes) {
      alert("Please provide overall notes.");
      return;
    }

    const submissionData = {
      ...formData,
      id: isEditing ? visitToEdit.id : undefined, // Add id for updates
      visit_date: format(formData.visit_date, 'yyyy-MM-dd')
    };
    
    // Pass the single data object
    onSubmit(submissionData);

    // Form reset is handled by useEffect when dialog state changes (e.g., onOpenChange(false))
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Store Visit" : "New Store Visit Evaluation"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Visit Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Location *</label>
                  <Select value={formData.location} onValueChange={(value) => setFormData({...formData, location: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ZIPZIP Causeway Bay">ZIPZIP Causeway Bay</SelectItem>
                      <SelectItem value="THE OLD BOOK STORE Causeway Bay">THE OLD BOOK STORE Causeway Bay</SelectItem>
                      <SelectItem value="NO MONEY SO LONELY Mongkok">NO MONEY SO LONELY Mongkok</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Visit Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.visit_date ? format(formData.visit_date, 'PPP') : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.visit_date}
                        onSelect={(date) => date && setFormData({...formData, visit_date: date})}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Visit Time</label>
                <Input
                  type="time"
                  value={formData.visit_time}
                  onChange={(e) => setFormData({...formData, visit_time: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>

          {/* Kitchen Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Kitchen Evaluation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Food Items Tried</label>
                <Textarea
                  value={formData.kitchen_food_tried}
                  onChange={(e) => setFormData({...formData, kitchen_food_tried: e.target.value})}
                  placeholder="List the food items you tried from the kitchen..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Wait Time</label>
                <Select value={formData.kitchen_wait_time} onValueChange={(value) => setFormData({...formData, kitchen_wait_time: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select wait time" />
                  </SelectTrigger>
                  <SelectContent>
                    {waitTimeOptions.map(option => (
                      <SelectItem key={option} value={option}>{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Food Review</label>
                <Textarea
                  value={formData.kitchen_food_review}
                  onChange={(e) => setFormData({...formData, kitchen_food_review: e.target.value})}
                  placeholder="Your review of the kitchen food quality, taste, presentation..."
                  className="h-24"
                />
              </div>
            </CardContent>
          </Card>

          {/* Bar/Dessert Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Bar & Dessert Evaluation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Items Tried</label>
                <Textarea
                  value={formData.bar_dessert_tried}
                  onChange={(e) => setFormData({...formData, bar_dessert_tried: e.target.value})}
                  placeholder="List the drinks and desserts you tried..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Wait Time</label>
                <Select value={formData.bar_wait_time} onValueChange={(value) => setFormData({...formData, bar_wait_time: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select wait time" />
                  </SelectTrigger>
                  <SelectContent>
                    {waitTimeOptions.map(option => (
                      <SelectItem key={option} value={option}>{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Food Review</label>
                <Textarea
                  value={formData.bar_food_review}
                  onChange={(e) => setFormData({...formData, bar_food_review: e.target.value})}
                  placeholder="Your review of the bar items and desserts..."
                  className="h-24"
                />
              </div>
            </CardContent>
          </Card>

          {/* Cleanliness Scores */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Cleanliness Scores</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Bar Cleanliness (1-10)</label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={formData.bar_cleanliness_score}
                      onChange={(e) => setFormData({...formData, bar_cleanliness_score: parseInt(e.target.value)})}
                    />
                    <Star className="w-4 h-4 text-amber-500" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Kitchen Cleanliness (1-10)</label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={formData.kitchen_cleanliness_score}
                      onChange={(e) => setFormData({...formData, kitchen_cleanliness_score: parseInt(e.target.value)})}
                    />
                    <Star className="w-4 h-4 text-amber-500" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Floor Cleanliness (1-10)</label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={formData.floor_cleanliness_score}
                      onChange={(e) => setFormData({...formData, floor_cleanliness_score: parseInt(e.target.value)})}
                    />
                    <Star className="w-4 h-4 text-amber-500" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Management Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Management Tasks Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {taskOptions.map(task => (
                  <div key={task} className="flex items-center space-x-2">
                    <Checkbox
                      id={task}
                      checked={formData.tasks_completed.includes(task)}
                      onCheckedChange={(checked) => handleTaskToggle(task, checked)}
                    />
                    <label htmlFor={task} className="text-sm font-medium leading-none">
                      {task}
                    </label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Overall Notes - Simplified */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Overall Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.overall_notes}
                onChange={(e) => setFormData({...formData, overall_notes: e.target.value})}
                placeholder="Provide your overall observations, issues, recommendations..."
                className="h-32"
              />
            </CardContent>
          </Card>

          {/* Photo Upload */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Photos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Main Photos (up to 10)</label>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e.target.files, 'photos')}
                  className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100"
                />
                {formData.photos.length > 0 && (
                  <p className="text-sm text-slate-600 mt-2">{formData.photos.length} photos uploaded</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Additional Photos (up to 5)</label>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e.target.files, 'additional_photos')}
                  className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100"
                />
                {formData.additional_photos.length > 0 && (
                  <p className="text-sm text-slate-600 mt-2">{formData.additional_photos.length} additional photos uploaded</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isUploading} className="bg-amber-500 hover:bg-amber-600">
            {isUploading ? (
              <>
                <Upload className="w-4 h-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              isEditing ? "Update Visit" : "Submit Visit"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
