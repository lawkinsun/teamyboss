import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, MapPin } from "lucide-react";
import { format, subDays, startOfDay } from "date-fns";

export default function VisitAnalytics({ visits }) {
  // Prepare data for charts
  const last30DaysData = React.useMemo(() => {
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const dayVisits = visits.filter(v => v.visit_date === dateStr);
      const avgScore = dayVisits.length > 0 ? 
        dayVisits.reduce((sum, v) => sum + (v.overall_score || 0), 0) / dayVisits.length : 0;
      
      return {
        date: format(date, 'MMM d'),
        visits: dayVisits.length,
        avgScore: Math.round(avgScore * 10) / 10
      };
    });
    return last30Days;
  }, [visits]);

  const locationData = React.useMemo(() => {
    const locations = ["ZIPZIP Causeway Bay", "THE OLD BOOK STORE Causeway Bay", "NO MONEY SO LONELY Mongkok"];
    return locations.map(location => {
      const locationVisits = visits.filter(v => v.location === location);
      const avgScore = locationVisits.length > 0 ? 
        locationVisits.reduce((sum, v) => sum + (v.overall_score || 0), 0) / locationVisits.length : 0;
      
      return {
        location: location.replace("Causeway Bay", "CWB").replace("Mongkok", "MK"),
        visits: locationVisits.length,
        avgScore: Math.round(avgScore * 10) / 10,
        avgCleanliness: locationVisits.length > 0 ? Math.round(
          locationVisits.reduce((sum, v) => sum + 
            ((v.bar_cleanliness_score || 0) + (v.kitchen_cleanliness_score || 0) + (v.floor_cleanliness_score || 0)) / 3, 0
          ) / locationVisits.length * 10
        ) / 10 : 0
      };
    });
  }, [visits]);

  if (visits.length === 0) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-8 text-center">
          <TrendingUp className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <p className="text-slate-500">No visit data available for analytics</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Visit Frequency Chart */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Visit Frequency (Last 30 Days)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={last30DaysData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="visits" 
                stroke="#f59e0b" 
                strokeWidth={2}
                name="Visits"
                dot={{ fill: '#f59e0b', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Location Comparison */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Location Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={locationData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="location" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="avgScore" fill="#10b981" name="Avg Score" />
              <Bar dataKey="avgCleanliness" fill="#3b82f6" name="Avg Cleanliness" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}