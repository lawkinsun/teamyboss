import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MapPin,
  Calendar,
  User,
  Star,
  Clock,
  CheckCircle,
  Camera,
  ExternalLink,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";

export default function VisitDetailModal({ visit, open, onOpenChange, tasks = [] }) {
  if (!visit) return null;

  const getScoreColor = (score) => {
    if (score >= 8) return "text-green-600 bg-green-100";
    if (score >= 7) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const getLocationColor = (location) => {
    if (location?.includes("ZIPZIP")) return "bg-amber-100 text-amber-800";
    if (location?.includes("OLD BOOK")) return "bg-blue-100 text-blue-800";
    if (location?.includes("NMSL") || location?.includes("NO MONEY")) return "bg-purple-100 text-purple-800";
    return "bg-gray-100 text-gray-800";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Store Visit Details
            </DialogTitle>
            <Badge className={getLocationColor(visit.location)}>
              {visit.location}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Visit Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <div>
                    <div className="font-medium">{format(new Date(visit.visit_date), 'MMMM d, yyyy')}</div>
                    {visit.visit_time && <div className="text-sm text-slate-500">{visit.visit_time}</div>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-500" />
                  <div>
                    <div className="font-medium">{visit.evaluator_name}</div>
                    <div className="text-sm text-slate-500">{visit.evaluator_email}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-slate-500" />
                  <div>
                    <div className={`text-2xl font-bold rounded-lg px-2 py-1 ${getScoreColor(visit.overall_score || 0)}`}>
                      {visit.overall_score ? visit.overall_score.toFixed(1) : 'N/A'}
                    </div>
                    <div className="text-sm text-slate-500">Overall Score</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Cleanliness Scores */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Cleanliness Evaluation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center bg-slate-50 rounded-lg p-4">
                  <div className={`text-3xl font-bold rounded-lg px-2 py-1 mb-2 ${getScoreColor(visit.bar_cleanliness_score || 0)}`}>
                    {visit.bar_cleanliness_score || 'N/A'}
                  </div>
                  <div className="font-medium">Bar Cleanliness</div>
                </div>
                <div className="text-center bg-slate-50 rounded-lg p-4">
                  <div className={`text-3xl font-bold rounded-lg px-2 py-1 mb-2 ${getScoreColor(visit.kitchen_cleanliness_score || 0)}`}>
                    {visit.kitchen_cleanliness_score || 'N/A'}
                  </div>
                  <div className="font-medium">Kitchen Cleanliness</div>
                </div>
                <div className="text-center bg-slate-50 rounded-lg p-4">
                  <div className={`text-3xl font-bold rounded-lg px-2 py-1 mb-2 ${getScoreColor(visit.floor_cleanliness_score || 0)}`}>
                    {visit.floor_cleanliness_score || 'N/A'}
                  </div>
                  <div className="font-medium">Floor Cleanliness</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Food Reviews */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Kitchen Evaluation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {visit.kitchen_food_tried && (
                  <div>
                    <div className="font-medium text-slate-700 mb-1">Items Tried:</div>
                    <p className="text-sm text-slate-600">{visit.kitchen_food_tried}</p>
                  </div>
                )}
                {visit.kitchen_wait_time && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span className="text-sm">Wait Time: {visit.kitchen_wait_time}</span>
                  </div>
                )}
                {visit.kitchen_food_review && (
                  <div>
                    <div className="font-medium text-slate-700 mb-1">Review:</div>
                    <p className="text-sm text-slate-600">{visit.kitchen_food_review}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Bar & Dessert Evaluation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {visit.bar_dessert_tried && (
                  <div>
                    <div className="font-medium text-slate-700 mb-1">Items Tried:</div>
                    <p className="text-sm text-slate-600">{visit.bar_dessert_tried}</p>
                  </div>
                )}
                {visit.bar_wait_time && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span className="text-sm">Wait Time: {visit.bar_wait_time}</span>
                  </div>
                )}
                {visit.bar_food_review && (
                  <div>
                    <div className="font-medium text-slate-700 mb-1">Review:</div>
                    <p className="text-sm text-slate-600">{visit.bar_food_review}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Management Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Management Tasks Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {[
                  "到 Eats365 查看營業額",
                  "到 Inline 留意訂位情況",
                  "到 TEAMY 了解排更情況",
                  "與當日店長 / 副店長溝通 10 分鐘",
                  "與大廚溝通 5 - 10 分鐘"
                ].map(task => {
                  const completed = visit.tasks_completed?.includes(task);
                  return (
                    <div key={task} className={`flex items-center gap-2 p-2 rounded-lg ${completed ? 'bg-green-50' : 'bg-gray-50'}`}>
                      <CheckCircle className={`w-4 h-4 ${completed ? 'text-green-500' : 'text-gray-400'}`} />
                      <span className={`text-sm ${completed ? 'text-green-800' : 'text-gray-600'}`}>
                        {task}
                      </span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 text-center">
                <Badge className={visit.tasks_completed?.length >= 4 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                  {visit.tasks_completed?.length || 0}/5 tasks completed
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Overall Notes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Overall Notes & Observations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-700 whitespace-pre-wrap">{visit.overall_notes}</p>
            </CardContent>
          </Card>

          {/* Photos */}
          {(visit.photos?.length > 0 || visit.additional_photos?.length > 0) && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  Visit Photos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {visit.photos?.length > 0 && (
                    <div>
                      <div className="font-medium mb-2">Main Photos:</div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {visit.photos.map((photo, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            className="h-24 p-1"
                            onClick={() => window.open(photo, '_blank')}
                          >
                            <img src={photo} alt={`Visit photo ${index + 1}`} className="w-full h-full object-cover rounded" />
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  {visit.additional_photos?.length > 0 && (
                    <div>
                      <div className="font-medium mb-2">Additional Photos:</div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {visit.additional_photos.map((photo, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            className="h-24 p-1"
                            onClick={() => window.open(photo, '_blank')}
                          >
                            <img src={photo} alt={`Additional photo ${index + 1}`} className="w-full h-full object-cover rounded" />
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Follow-up Tasks */}
          {tasks.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 text-red-700">
                  <AlertTriangle className="w-5 h-5" />
                  Follow-up Actions Created
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {tasks.map(task => (
                    <div key={task.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-red-200">
                      <div>
                        <div className="font-medium text-red-800">{task.title}</div>
                        <div className="text-sm text-red-600">{task.description}</div>
                      </div>
                      <Badge className="bg-red-100 text-red-800">
                        {task.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}