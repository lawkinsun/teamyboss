import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MapPin,
  Star,
  Calendar,
  User,
  Camera,
  CheckCircle,
  AlertTriangle,
  Eye,
  Edit,
} from "lucide-react";
import { format } from "date-fns";

export default function StoreVisitCard({ visit, onViewDetails, onEdit, isAdmin }) {
  const getScoreColor = (score) => {
    if (score >= 8) return "text-green-600 bg-green-100";
    if (score >= 7) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const getLocationColor = (location) => {
    if (location?.includes("ZIPZIP")) return "bg-amber-100 text-amber-800";
    if (location?.includes("OLD BOOK")) return "bg-blue-100 text-blue-800";
    if (location?.includes("NMSL") || location?.includes("NO MONEY")) return "bg-purple-100 text-purple-800";
    return "bg-gray-100 text-gray-800";
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex flex-col space-y-3">
          {/* Header Row */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <Badge className={`${getLocationColor(visit.location)} mb-2`} variant="secondary">
                {visit.location?.replace("Causeway Bay", "CWB").replace("Mongkok", "MK") || "Unknown Location"}
              </Badge>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Calendar className="w-3 h-3" />
                <span>
                  {visit.visit_date ? format(new Date(visit.visit_date), 'MMM d, yyyy') : 'No date'}
                </span>
              </div>
            </div>
            <div className="flex flex-col items-center">
              <div className={`text-2xl font-bold rounded-lg px-2 py-1 ${getScoreColor(visit.overall_score || 0)}`}>
                {visit.overall_score ? visit.overall_score.toFixed(1) : 'N/A'}
              </div>
              <div className="text-xs text-slate-500 mt-1">Overall</div>
            </div>
          </div>

          {/* Evaluator */}
          <div className="flex items-center gap-2">
            <User className="w-3 h-3 text-slate-500" />
            <span className="text-sm font-medium text-slate-700">{visit.evaluator_name || 'Unknown'}</span>
          </div>

          {/* Scores Row */}
          <div className="flex justify-between text-center">
            <div className="flex flex-col items-center p-2 bg-slate-50 rounded-lg flex-1 mx-1">
              <div className="text-sm font-semibold text-slate-800">
                {visit.bar_cleanliness_score || 'N/A'}
              </div>
              <div className="text-xs text-slate-500">Bar</div>
            </div>
            <div className="flex flex-col items-center p-2 bg-slate-50 rounded-lg flex-1 mx-1">
              <div className="text-sm font-semibold text-slate-800">
                {visit.kitchen_cleanliness_score || 'N/A'}
              </div>
              <div className="text-xs text-slate-500">Kitchen</div>
            </div>
            <div className="flex flex-col items-center p-2 bg-slate-50 rounded-lg flex-1 mx-1">
              <div className="text-sm font-semibold text-slate-800">
                {visit.floor_cleanliness_score || 'N/A'}
              </div>
              <div className="text-xs text-slate-500">Floor</div>
            </div>
          </div>

          {/* Notes Preview */}
          <p className="text-sm text-slate-600 line-clamp-2">
            {visit.overall_notes?.substring(0, 100)}
            {visit.overall_notes?.length > 100 && "..."}
          </p>

          {/* Action Items Alert */}
          {visit.action_items_created?.length > 0 && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg p-2">
              <AlertTriangle className="w-3 h-3 text-red-500 flex-shrink-0" />
              <span className="text-xs text-red-600">
                {visit.action_items_created.length} follow-up task{visit.action_items_created.length > 1 ? 's' : ''} created
              </span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={onViewDetails}
              variant="outline"
              size="sm"
              className="flex-1 hover:bg-amber-50 hover:border-amber-200"
            >
              <Eye className="w-3 h-3 mr-1" />
              Details
            </Button>
            {isAdmin && (
              <Button
                onClick={onEdit}
                variant="outline"
                size="sm"
                className="flex-1 hover:bg-blue-50 hover:border-blue-200"
              >
                <Edit className="w-3 h-3 mr-1" />
                Edit
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}