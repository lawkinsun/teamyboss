
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Briefcase, 
  Building2,
  Brush,
  Code,
  Utensils,
  MoreVertical,
  Edit
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const projectIcons = {
  Restaurant: <Utensils className="w-8 h-8 text-amber-500" />,
  Construction: <Building2 className="w-8 h-8 text-blue-500" />,
  Events: <Brush className="w-8 h-8 text-purple-500" />,
  Tech: <Code className="w-8 h-8 text-green-500" />,
  Other: <Briefcase className="w-8 h-8 text-slate-500" />
};

// Function to check if a string is a valid number
const isNumeric = (str) => {
  if (typeof str != "string") return false // we only process strings!  
  return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
         !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
}

const ProjectGoalDisplay = ({ goal }) => {
  if (!goal) {
    return (
      <>
        <div className="text-xs text-slate-500">Project Goal</div>
        <div className="font-bold text-slate-700">-</div>
      </>
    );
  }

  if (isNumeric(goal)) {
    return (
      <>
        <div className="text-xs text-slate-500">Project Goal</div>
        <div className="font-bold text-slate-700 break-words">
          HK${parseInt(goal, 10).toLocaleString()}
        </div>
      </>
    );
  }

  return (
    <>
      <div className="text-xs text-slate-500">Project Goal</div>
      <div className="font-bold text-slate-700 break-words">{goal}</div>
    </>
  );
};


export default function ProjectCard({ project, onEdit }) {
  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-slate-100 rounded-lg">
            {projectIcons[project.type] || projectIcons['Other']}
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <h3 className="font-bold text-slate-800 text-lg mb-1">{project.name}</h3>
               <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => onEdit(project)}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Project
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <p className="text-sm text-slate-600 mb-2">{project.description}</p>
            <div className="text-xs text-slate-500">
              Managed by: <span className="font-medium">{project.manager}</span>
            </div>
             <Badge className={`mt-2 ${
                project.status === 'Active' ? 'bg-green-100 text-green-800' : 
                project.status === 'Planning' ? 'bg-blue-100 text-blue-800' :
                project.status === 'Completed' ? 'bg-purple-100 text-purple-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {project.status}
              </Badge>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-slate-200 flex justify-between items-center">
          <div className="min-w-0 flex-1">
            <ProjectGoalDisplay goal={project.project_goal} />
          </div>
          <Button asChild size="sm" className="ml-4 flex-shrink-0 bg-white border border-slate-300 text-slate-800 hover:bg-slate-100">
            <Link to={createPageUrl(`ProjectDetail?id=${project.id}`)}>View Dashboard</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
