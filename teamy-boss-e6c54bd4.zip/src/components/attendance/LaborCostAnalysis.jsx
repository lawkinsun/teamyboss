import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, Users, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function LaborCostAnalysis({ schedules, staff, selectedLocation }) {
  const calculateLaborMetrics = () => {
    const filteredSchedules = selectedLocation === 'all' 
      ? schedules 
      : schedules.filter(s => s.location === selectedLocation);

    // Group by location
    const locationMetrics = {};
    
    filteredSchedules.forEach(schedule => {
      const location = schedule.location;
      if (!locationMetrics[location]) {
        locationMetrics[location] = {
          location: location.replace(' Causeway Bay', '').replace(' Mongkok', ''),
          totalCost: 0,
          totalHours: 0,
          staffCount: new Set(),
          lateCount: 0,
          absentCount: 0,
          overtimeHours: 0
        };
      }

      const metrics = locationMetrics[location];
      const hours = calculateShiftHours(schedule.shift_start, schedule.shift_end);
      
      metrics.totalHours += hours;
      metrics.totalCost += hours * (schedule.hourly_rate || 60);
      metrics.staffCount.add(schedule.staff_name);
      metrics.overtimeHours += schedule.overtime_hours || 0;
      
      if (schedule.status === 'late') metrics.lateCount++;
      if (schedule.status === 'absent') metrics.absentCount++;
    });

    // Convert Set to count
    Object.values(locationMetrics).forEach(metrics => {
      metrics.staffCount = metrics.staffCount.size;
    });

    return Object.values(locationMetrics);
  };

  const calculateShiftHours = (start, end) => {
    if (!start || !end) return 8;
    const startHour = parseInt(start.split(':')[0]);
    const endHour = parseInt(end.split(':')[0]);
    return endHour > startHour ? endHour - startHour : (24 - startHour) + endHour;
  };

  const getTopIssues = () => {
    const issues = {};
    
    schedules.forEach(schedule => {
      if (schedule.status === 'late' || schedule.status === 'absent' || schedule.status === 'sick_leave') {
        const key = `${schedule.staff_name} - ${schedule.status}`;
        issues[key] = (issues[key] || 0) + 1;
      }
    });

    return Object.entries(issues)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([issue, count]) => ({ issue, count }));
  };

  const getHolidayBalances = () => {
    return staff
      .filter(s => s.holiday_balance > 5)
      .sort((a, b) => b.holiday_balance - a.holiday_balance)
      .slice(0, 5);
  };

  const laborMetrics = calculateLaborMetrics();
  const topIssues = getTopIssues();
  const holidayBalances = getHolidayBalances();
  
  const totalCost = laborMetrics.reduce((sum, m) => sum + m.totalCost, 0);
  const totalHours = laborMetrics.reduce((sum, m) => sum + m.totalHours, 0);
  const avgHourlyRate = totalHours > 0 ? totalCost / totalHours : 0;

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {/* Labor Cost Chart */}
      <Card className="md:col-span-2 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Labor Cost Analysis by Location
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={laborMetrics}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="location" />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'totalCost' ? `$${value.toLocaleString()}` : value,
                    name === 'totalCost' ? 'Labor Cost' : 'Total Hours'
                  ]}
                />
                <Bar dataKey="totalCost" fill="#f59e0b" name="Cost" />
                <Bar dataKey="totalHours" fill="#3b82f6" name="Hours" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 rounded-lg bg-green-50 border border-green-200">
              <div className="text-lg font-bold text-green-800">${totalCost.toLocaleString()}</div>
              <div className="text-sm text-green-600">Total Cost</div>
            </div>
            <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
              <div className="text-lg font-bold text-blue-800">{totalHours}</div>
              <div className="text-sm text-blue-600">Total Hours</div>
            </div>
            <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
              <div className="text-lg font-bold text-purple-800">${avgHourlyRate.toFixed(0)}</div>
              <div className="text-sm text-purple-600">Avg Rate/Hour</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Issues & Alerts */}
      <div className="space-y-6">
        {/* Attendance Issues */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Top Attendance Issues
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {topIssues.map((issue, index) => (
                <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-orange-50 border border-orange-200">
                  <span className="text-sm text-orange-800">{issue.issue}</span>
                  <Badge className="bg-orange-100 text-orange-800">{issue.count}x</Badge>
                </div>
              ))}
              {topIssues.length === 0 && (
                <div className="text-center py-4 text-slate-500">
                  <p className="text-sm">No major issues this period!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Holiday Balances */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-500" />
              High Holiday Balances
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {holidayBalances.map((staff, index) => (
                <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                  <div>
                    <div className="text-sm font-medium text-blue-800">{staff.name}</div>
                    <div className="text-xs text-blue-600">{staff.position}</div>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">{staff.holiday_balance} days</Badge>
                </div>
              ))}
              {holidayBalances.length === 0 && (
                <div className="text-center py-4 text-slate-500">
                  <p className="text-sm">No high holiday balances</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}