import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Users, MapPin } from "lucide-react";
import { format, startOfWeek, addDays } from "date-fns";

export default function ScheduleCalendar({ schedules, selectedWeek, onMarkAttendance }) {
  const weekStart = startOfWeek(selectedWeek, { weekStartsOn: 1 }); // Monday start
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  const getSchedulesForDay = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return schedules.filter(s => s.date === dateStr);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-800 border-green-200';
      case 'late': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'absent': return 'bg-red-100 text-red-800 border-red-200';
      case 'sick_leave': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'holiday': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'scheduled': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const groupSchedulesByLocation = (daySchedules) => {
    const grouped = {};
    daySchedules.forEach(schedule => {
      if (!grouped[schedule.location]) {
        grouped[schedule.location] = [];
      }
      grouped[schedule.location].push(schedule);
    });
    return grouped;
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <Calendar className="w-5 h-5" />
          Weekly Staff Schedule
        </CardTitle>
        <div className="text-sm text-slate-600">
          Week of {format(weekStart, 'MMM d')} - {format(addDays(weekStart, 6), 'MMM d, yyyy')}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-7 gap-4">
          {weekDays.map((day, index) => {
            const daySchedules = getSchedulesForDay(day);
            const groupedSchedules = groupSchedulesByLocation(daySchedules);
            const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
            
            return (
              <div
                key={index}
                className={`p-3 rounded-lg border ${
                  isToday ? 'border-amber-300 bg-amber-50' : 'border-slate-200 bg-slate-50'
                }`}
              >
                <div className="font-medium text-slate-800 mb-2">
                  {format(day, 'EEE')}
                  <div className="text-sm font-normal text-slate-600">
                    {format(day, 'MMM d')}
                  </div>
                </div>
                
                <div className="space-y-2">
                  {Object.entries(groupedSchedules).map(([location, locationSchedules]) => (
                    <div key={location} className="space-y-1">
                      <div className="text-xs font-medium text-slate-700 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {location.replace(' Causeway Bay', '').replace(' Mongkok', '')}
                      </div>
                      
                      {locationSchedules.map((schedule) => (
                        <div
                          key={schedule.id}
                          className="p-2 rounded border border-slate-200 bg-white"
                        >
                          <div className="text-xs font-medium text-slate-800">
                            {schedule.staff_name}
                          </div>
                          <div className="text-xs text-slate-600 flex items-center gap-1 mt-1">
                            <Clock className="w-3 h-3" />
                            {schedule.shift_start} - {schedule.shift_end}
                          </div>
                          
                          <div className="flex items-center justify-between mt-2">
                            <Badge className={`text-xs ${getStatusColor(schedule.status)}`}>
                              {schedule.status === 'scheduled' ? 'Scheduled' :
                               schedule.status === 'present' ? 'Present' :
                               schedule.status === 'late' ? `Late ${schedule.minutes_late}m` :
                               schedule.status === 'sick_leave' ? 'Sick' :
                               schedule.status}
                            </Badge>
                            
                            {schedule.status === 'scheduled' && isToday && (
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onMarkAttendance(schedule.id, 'present', new Date().toTimeString().slice(0, 5))}
                                  className="text-xs px-1 py-0.5 h-6"
                                >
                                  ✓
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onMarkAttendance(schedule.id, 'absent', null)}
                                  className="text-xs px-1 py-0.5 h-6"
                                >
                                  ✗
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ))}
                  
                  {daySchedules.length === 0 && (
                    <div className="text-xs text-slate-500 text-center py-2">
                      No shifts scheduled
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}