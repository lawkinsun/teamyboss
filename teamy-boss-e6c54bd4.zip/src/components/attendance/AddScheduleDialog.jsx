import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Calendar } from "lucide-react";

export default function AddScheduleDialog({ open, onOpenChange, onSubmit, staff }) {
  const [formData, setFormData] = useState({
    staff_name: "",
    employee_id: "",
    location: "ZIPZIP Causeway Bay",
    date: "",
    shift_start: "",
    shift_end: "",
    hourly_rate: 60,
    status: "scheduled"
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Find selected staff member to get employee_id
    const selectedStaff = staff.find(s => s.name === formData.staff_name);
    if (selectedStaff) {
      const scheduleData = {
        ...formData,
        employee_id: selectedStaff.employee_id,
        hourly_rate: selectedStaff.hourly_rate || 60
      };
      onSubmit(scheduleData);
    }
    
    // Reset form
    setFormData({
      staff_name: "",
      employee_id: "",
      location: "ZIPZIP Causeway Bay",
      date: "",
      shift_start: "",
      shift_end: "",
      hourly_rate: 60,
      status: "scheduled"
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Add Staff Schedule
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="staff_name">Staff Member</Label>
            <Select 
              value={formData.staff_name} 
              onValueChange={(value) => setFormData({...formData, staff_name: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select staff member" />
              </SelectTrigger>
              <SelectContent>
                {staff.map(member => (
                  <SelectItem key={member.id} value={member.name}>
                    {member.name} - {member.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Select 
              value={formData.location} 
              onValueChange={(value) => setFormData({...formData, location: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ZIPZIP Causeway Bay">ZIPZIP Causeway Bay</SelectItem>
                <SelectItem value="THE OLD BOOK STORE Causeway Bay">THE OLD BOOK STORE Causeway Bay</SelectItem>
                <SelectItem value="NO MONEY SO LONELY Mongkok">NO MONEY SO LONELY Mongkok</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({...formData, date: e.target.value})}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="shift_start">Start Time</Label>
              <Input
                id="shift_start"
                type="time"
                value={formData.shift_start}
                onChange={(e) => setFormData({...formData, shift_start: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="shift_end">End Time</Label>
              <Input
                id="shift_end"
                type="time"
                value={formData.shift_end}
                onChange={(e) => setFormData({...formData, shift_end: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-amber-500 hover:bg-amber-600">
              <Plus className="w-4 h-4 mr-2" />
              Add Schedule
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}