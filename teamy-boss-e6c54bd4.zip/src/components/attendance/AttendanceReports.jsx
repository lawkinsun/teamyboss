import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Calendar, TrendingDown, Clock } from "lucide-react";
import { format, subDays } from "date-fns";

export default function AttendanceReports({ schedules, staff }) {
  const generateWeeklyReport = () => {
    const lastWeek = subDays(new Date(), 7);
    const weeklyData = schedules.filter(s => new Date(s.date) >= lastWeek);
    
    const report = {
      totalShifts: weeklyData.length,
      presentCount: weeklyData.filter(s => s.status === 'present').length,
      lateCount: weeklyData.filter(s => s.status === 'late').length,
      absentCount: weeklyData.filter(s => s.status === 'absent').length,
      sickLeaveCount: weeklyData.filter(s => s.status === 'sick_leave').length,
      attendanceRate: 0
    };
    
    const attendedShifts = report.presentCount + report.lateCount;
    report.attendanceRate = report.totalShifts > 0 ? (attendedShifts / report.totalShifts * 100).toFixed(1) : 0;
    
    return report;
  };

  const getProblemStaff = () => {
    const staffIssues = {};
    
    schedules.forEach(schedule => {
      if (schedule.status === 'late' || schedule.status === 'absent') {
        if (!staffIssues[schedule.staff_name]) {
          staffIssues[schedule.staff_name] = { late: 0, absent: 0, total: 0 };
        }
        
        if (schedule.status === 'late') staffIssues[schedule.staff_name].late++;
        if (schedule.status === 'absent') staffIssues[schedule.staff_name].absent++;
        staffIssues[schedule.staff_name].total++;
      }
    });
    
    return Object.entries(staffIssues)
      .sort(([,a], [,b]) => b.total - a.total)
      .slice(0, 3)
      .map(([name, issues]) => ({ name, ...issues }));
  };

  const getOverstaffingDays = () => {
    const dailyStaffing = {};
    
    schedules.forEach(schedule => {
      const key = `${schedule.date}-${schedule.location}`;
      if (!dailyStaffing[key]) {
        dailyStaffing[key] = { 
          date: schedule.date, 
          location: schedule.location, 
          count: 0 
        };
      }
      if (schedule.status === 'present' || schedule.status === 'late') {
        dailyStaffing[key].count++;
      }
    });
    
    // Consider overstaffed if more than 6 people present at once
    return Object.values(dailyStaffing)
      .filter(day => day.count > 6)
      .sort((a, b) => b.count - a.count)
      .slice(0, 3);
  };

  const exportReport = () => {
    const report = generateWeeklyReport();
    const problemStaff = getProblemStaff();
    const overstaffing = getOverstaffingDays();
    
    const csvData = [
      ['Weekly Attendance Report', format(new Date(), 'yyyy-MM-dd')],
      [''],
      ['Summary'],
      ['Total Shifts', report.totalShifts],
      ['Present', report.presentCount],
      ['Late', report.lateCount],
      ['Absent', report.absentCount],
      ['Sick Leave', report.sickLeaveCount],
      ['Attendance Rate', `${report.attendanceRate}%`],
      [''],
      ['Problem Staff'],
      ['Name', 'Late Count', 'Absent Count', 'Total Issues'],
      ...problemStaff.map(staff => [staff.name, staff.late, staff.absent, staff.total]),
      [''],
      ['Overstaffed Days'],
      ['Date', 'Location', 'Staff Count'],
      ...overstaffing.map(day => [day.date, day.location, day.count])
    ];
    
    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `attendance-report-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  const weeklyReport = generateWeeklyReport();
  const problemStaff = getProblemStaff();
  const overstaffing = getOverstaffingDays();

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Weekly Attendance Report
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={exportReport}
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 rounded-lg bg-green-50 border border-green-200">
            <div className="text-2xl font-bold text-green-800">{weeklyReport.attendanceRate}%</div>
            <div className="text-sm text-green-600">Attendance Rate</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-orange-50 border border-orange-200">
            <div className="text-2xl font-bold text-orange-800">{weeklyReport.lateCount}</div>
            <div className="text-sm text-orange-600">Late Arrivals</div>
          </div>
        </div>

        {/* Problem Staff */}
        <div>
          <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-red-500" />
            Staff Needing Attention
          </h4>
          <div className="space-y-2">
            {problemStaff.map((staff, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                <div>
                  <div className="font-medium text-red-800">{staff.name}</div>
                  <div className="text-sm text-red-600">
                    {staff.late} late, {staff.absent} absent
                  </div>
                </div>
                <Badge className="bg-red-100 text-red-800">{staff.total} issues</Badge>
              </div>
            ))}
            {problemStaff.length === 0 && (
              <div className="text-center py-4 text-slate-500">
                <p className="text-sm">No major attendance issues this week!</p>
              </div>
            )}
          </div>
        </div>

        {/* Overstaffing Alert */}
        {overstaffing.length > 0 && (
          <div>
            <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-500" />
              Potential Overstaffing
            </h4>
            <div className="space-y-2">
              {overstaffing.map((day, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                  <div>
                    <div className="font-medium text-blue-800">{format(new Date(day.date), 'MMM d')}</div>
                    <div className="text-sm text-blue-600">{day.location.replace(' Causeway Bay', '').replace(' Mongkok', '')}</div>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">{day.count} staff</Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}