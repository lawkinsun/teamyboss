
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Clock, 
  User, 
  MapPin, 
  AlertTriangle, 
  CheckCircle,
  Coffee,
  Calendar,
  Users // Added Users import
} from "lucide-react";
import { format } from "date-fns";

export default function StaffAttendanceCard({ staff, todaySchedules, onMarkAttendance }) {
  const getAttendanceStatus = (staffName) => {
    const schedule = todaySchedules.find(s => s.staff_name === staffName);
    return schedule?.status || 'not_scheduled';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-800 border-green-200';
      case 'late': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'absent': return 'bg-red-100 text-red-800 border-red-200';
      case 'sick_leave': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'holiday': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'not_scheduled': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'present': return <CheckCircle className="w-4 h-4" />;
      case 'late': return <Clock className="w-4 h-4" />;
      case 'absent': return <User className="w-4 h-4" />;
      case 'sick_leave': return <Coffee className="w-4 h-4" />;
      case 'holiday': return <Calendar className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <Users className="w-5 h-5" />
          Staff Attendance Today
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {staff.map((member) => {
            const status = getAttendanceStatus(member.name);
            const schedule = todaySchedules.find(s => s.staff_name === member.name);
            
            return (
              <div
                key={member.id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200"
              >
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-500 text-white font-bold text-sm">
                      {member.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-slate-800">{member.name}</p>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span>{member.position}</span>
                      <MapPin className="w-3 h-3" />
                      <span>{member.location.replace(' Causeway Bay', '').replace(' Mongkok', '')}</span>
                    </div>
                    {schedule && (
                      <div className="text-xs text-slate-500">
                        {schedule.shift_start} - {schedule.shift_end}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Badge className={`text-xs ${getStatusColor(status)}`}>
                    {getStatusIcon(status)}
                    <span className="ml-1">
                      {status === 'not_scheduled' ? 'Off' : 
                       status === 'sick_leave' ? 'Sick' :
                       status === 'present' ? 'Present' :
                       status === 'late' ? `Late ${schedule?.minutes_late || 0}m` :
                       status}
                    </span>
                  </Badge>
                  
                  {schedule && schedule.status === 'scheduled' && (
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onMarkAttendance(schedule.id, 'present', new Date().toTimeString().slice(0, 5))}
                        className="text-xs px-2 py-1"
                      >
                        Present
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onMarkAttendance(schedule.id, 'absent', null)}
                        className="text-xs px-2 py-1"
                      >
                        Absent
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
